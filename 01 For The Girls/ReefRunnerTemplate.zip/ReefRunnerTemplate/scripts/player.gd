extends CharacterBody2D

# ============================================================
#  PLAYER  —  MOD ME!  Change a number, then press Play (F5).
# ============================================================
@export var speed: float = 250.0         # how fast she runs
@export var jump_force: float = -550.0    # how high she jumps (negative = UP)
@export var gravity: float = 1200.0       # how hard she falls back down

@onready var visual: Sprite2D = get_node_or_null("Sprite2D")

var _was_jump: bool = false


func _physics_process(delta: float) -> void:
	# 1. Gravity pulls her down when she is not on the floor.
	if not is_on_floor():
		velocity.y += gravity * delta

	# 2. Move left / right (Arrow keys OR A and D).
	var direction: float = 0.0
	if Input.is_key_pressed(KEY_LEFT) or Input.is_key_pressed(KEY_A):
		direction -= 1.0
	if Input.is_key_pressed(KEY_RIGHT) or Input.is_key_pressed(KEY_D):
		direction += 1.0

	if direction != 0.0:
		velocity.x = direction * speed
		if visual:
			visual.flip_h = direction < 0.0      # face the way she walks
	else:
		velocity.x = move_toward(velocity.x, 0.0, speed)

	# 3. Jump (Space OR Up) — only when standing on the ground.
	var jump_key: bool = Input.is_key_pressed(KEY_SPACE) or Input.is_key_pressed(KEY_UP)
	if jump_key and not _was_jump and is_on_floor():
		velocity.y = jump_force
	_was_jump = jump_key

	# 4. Do the move.
	move_and_slide()
