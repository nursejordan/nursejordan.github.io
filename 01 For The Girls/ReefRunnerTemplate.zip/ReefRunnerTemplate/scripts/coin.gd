extends Area2D

# ============================================================
#  REEF  —  a thing to collect.  MOD ME!
# ============================================================
@export var spin_speed: float = 2.0       # how fast it spins (try 0 or 8)

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _process(delta: float) -> void:
	rotation += spin_speed * delta

func _on_body_entered(body: Node) -> void:
	# Only react to the player, not the ground or platforms.
	if body is CharacterBody2D:
		var gm := get_tree().get_first_node_in_group("gm")
		if gm:
			gm.save_reef()
		queue_free()      # the reef disappears once it is saved
