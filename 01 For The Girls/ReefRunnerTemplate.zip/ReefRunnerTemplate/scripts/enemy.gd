extends Area2D

# ============================================================
#  ENEMY  —  patrols back and forth.  MOD ME!
# ============================================================
@export var speed: float = 100.0           # how fast it slides
@export var move_distance: float = 200.0    # how far before it turns around

var _start: Vector2
var _dir: int = 1

func _ready() -> void:
	_start = position
	body_entered.connect(_on_body_entered)

func _process(delta: float) -> void:
	position.x += speed * _dir * delta
	if abs(position.x - _start.x) > move_distance:
		_dir *= -1                # turn around at the edge

func _on_body_entered(body: Node) -> void:
	if body is CharacterBody2D:
		var gm := get_tree().get_first_node_in_group("gm")
		if gm:
			gm.lose_life()
