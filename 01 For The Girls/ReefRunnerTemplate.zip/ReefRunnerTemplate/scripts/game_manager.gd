extends Node

# ============================================================
#  GAME MANAGER  —  keeps the score and lives.  MOD ME!
# ============================================================
@export var starting_lives: int = 3        # how many lives she starts with

var lives: int = 0
var reefs_saved: int = 0
var game_over: bool = false

@onready var lives_label: Label = get_node_or_null("../HUD/LivesLabel")
@onready var reef_label: Label = get_node_or_null("../HUD/ReefLabel")
@onready var game_over_label: Label = get_node_or_null("../HUD/GameOverLabel")

func _ready() -> void:
	lives = starting_lives
	if game_over_label:
		game_over_label.visible = false
	_update()

func save_reef() -> void:
	if game_over:
		return
	reefs_saved += 1
	_update()

func lose_life() -> void:
	if game_over:
		return
	lives -= 1
	_update()
	if lives <= 0:
		_show_game_over()

func _update() -> void:
	if lives_label:
		lives_label.text = "Lives: %d" % lives
	if reef_label:
		reef_label.text = "Reefs saved: %d" % reefs_saved

func _show_game_over() -> void:
	game_over = true
	if game_over_label:
		game_over_label.text = "Game Over!\nYou saved %d reefs!" % reefs_saved
		game_over_label.visible = true
