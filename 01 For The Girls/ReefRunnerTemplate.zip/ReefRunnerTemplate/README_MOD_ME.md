# 🐠 Reef Runner — a game you can MOD

This is a whole little game that already works. Your job is **not** to build it —
it's to **change it** and see what happens. That's how you learn Godot.

## How to open it
1. Open the **Godot** app.
2. Click **Import**, find this folder, open **project.godot**, click **Import & Edit**.
3. Press **▶ Play** (top-right) or **F5**.
4. Move with the **arrow keys** (or **A / D**). Jump with **Space** (or **Up**).
   - Walk into a **yellow reef** → score goes up.
   - Touch the **red enemy** → you lose a life.

## The 4 colours (same as your guide)
- 🟩 **Parts list** (left) — click a piece here first.
- 🟧 **Settings / Inspector** (right) — its knobs show up here.
- 🟦 **Stage** (middle) — drag pieces to move them.
- 🟪 **Files** (bottom-left) — the scripts and the fish picture live here.

---

## 🎛️ Things to change (start here!)

### Make the player feel different
Click **Player** in the Parts list. In the Inspector you'll see:
| Knob | Try this | What happens |
|---|---|---|
| **Speed** | 400 | she runs faster |
| **Jump Force** | −650 | she jumps way higher (keep it **negative**) |
| **Gravity** | 600 | she floats down slowly, like she's underwater |

### Change the colours
Click **Ground** ▸ **Visual** (or Platform1, Platform2). In the Inspector find **Color** and pick a new one.
Click a **Coin** ▸ **Sprite2D**, find **Modulate**, and recolour the reef.

### Move things around
In the **Stage**, drag the **Platforms**, **Coins**, and **Enemy** anywhere you like.

### Make it harder or easier
- Click **Enemy1** → change **Speed** and **Move Distance**.
- Click **GameManager** → change **Starting Lives**.

### Add more reefs
Right-click **Coin1** ▸ **Duplicate**. Drag the copy somewhere new. Done — it already works!

### Reskin the fish
Replace **icon.svg** in the Files panel with your own picture (draw one in Piskel!),
and every fish, reef and enemy uses your art.

---

## 🧩 The pieces (what each one is)
- **Player** — a `CharacterBody2D` with the movement brain (`player.gd`).
- **Ground / Platform1 / Platform2** — `StaticBody2D` — solid things to stand on.
- **Coin1–3** — `Area2D` reefs (`coin.gd`) — score when touched.
- **Enemy1** — `Area2D` (`enemy.gd`) — patrols and costs a life.
- **GameManager** — keeps lives + score (`game_manager.gd`).
- **HUD** — the Lives / Reefs text on screen.

Every script has **MOD ME!** notes at the top telling you what each number does.

Have fun. Break it, undo (Ctrl/⌘ + Z), try again — that's exactly how game makers work. 🎉
